import pygame

pygame.init()


screen = pygame.display.set_mode((800, 600))
pygame.display.set_caption("OreaForge")


player_image = pygame.image.load("Player.png")
player_image = pygame.transform.scale(player_image, (43, 100))  


player_x = 100
player_y = 100
player_speed = 5

running = True

while running:
    pygame.time.delay(30)  


    for event in pygame.event.get():
        if event.type == pygame.QUIT:  
            running = False


    keys = pygame.key.get_pressed()
    
   
    if keys[pygame.K_w]:  
        player_y -= player_speed
    if keys[pygame.K_s]:  
        player_y += player_speed
    if keys[pygame.K_a]:  
        player_x -= player_speed
    if keys[pygame.K_d]:  
        player_x += player_speed

    
    screen.fill((255, 255, 255))

    screen.blit(player_image, (player_x, player_y))

    pygame.display.flip()  

pygame.quit()

